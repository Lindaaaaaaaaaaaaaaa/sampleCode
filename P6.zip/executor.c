/*119690833
Chuqiao Yan
chuqiaoy*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include "command.h"
#include "executor.h"

#define MAX_PIPE_CMDS 128

static void print_tree(struct tree *t);

static int collect_pipeline(struct tree *t, struct tree **cmds, int max) {
  int left_count;
  int right_count;
    if (!t || max <= 0) return 0;

    if(t->left != NULL && t->left->output != NULL){
      printf("Ambiguous output redirect.\n");
      return -1;
      }
    if (t->conjunction == PIPE) {
         left_count = collect_pipeline(t->left, cmds, max);
	if(left_count == -1) return -1;
         right_count = collect_pipeline(t->right, cmds + left_count, max - left_count);
	if(right_count == -1) return -1;
        return left_count + right_count;
    } else {
        cmds[0] = t;
        return 1;
    }
}

int execute(struct tree *t) {
  
    int ret_val;
    
    ret_val = -1;
    if (!t) return ret_val;

    if (t->conjunction == NONE) {
        int status;
        pid_t pid;

	if(strcmp(t->argv[0],"cd") == 0){
	  chdir(t->argv[1]);
	  return 0;
	}else if(strcmp(t->argv[0],"exit") == 0){
	  exit(0);
	}

        pid = fork();
        if (pid == 0) {
	  
	  if (t->input != NULL) {
	    int fd = open(t->input,O_RDONLY);
	    if(fd < 0){
	      exit(1);
	    }
	    dup2(fd,STDIN_FILENO);
	    close(fd);
            
	  }

	  if(t->output != NULL){
	    int fd = open(t->output,O_WRONLY| O_CREAT | O_TRUNC,0666);
	    if(fd<0){
	      exit(1);
	    }
	    dup2(fd,STDOUT_FILENO);
	    close(fd);
	  }
	  execvp(t->argv[0],t->argv);
	  exit(1);
	}
        waitpid(pid, &status, 0);
	if(WIFEXITED(status) && WEXITSTATUS(status) == 0)
	  ret_val = 0;
	else
	  ret_val = -1;

        return ret_val;
    }
    else if (t->conjunction == AND) {
        if (t->left) ret_val = execute(t->left);
        if (t->left && ret_val == 0 && t->right) ret_val = execute(t->right);
        return ret_val;
    }
    else if (t->conjunction == PIPE) {
        struct tree *cmds[MAX_PIPE_CMDS];
        int ncmds, i, j;
        int pipes[MAX_PIPE_CMDS-1][2];
        int parent_pipe[2];
        pid_t pids[MAX_PIPE_CMDS];
        ssize_t rn;
        char buf[512];
        size_t total;
        char *outbuf;

        ncmds = collect_pipeline(t, cmds, MAX_PIPE_CMDS);
        if (ncmds <= 0) return -1;

        for (i = 0; i < ncmds - 1; i++) pipe(pipes[i]);
        pipe(parent_pipe);

        for (i = 0; i < ncmds; i++) {

            pid_t cpid = fork();
            if (cpid == 0) {
                if (i > 0) dup2(pipes[i-1][0], STDIN_FILENO);
                if (i < ncmds - 1) dup2(pipes[i][1], STDOUT_FILENO);
                else dup2(parent_pipe[1], STDOUT_FILENO);
                for (j = 0; j < ncmds - 1; j++) { 
		  close(pipes[j][0]); close(pipes[j][1]); 
		}
                close(parent_pipe[0]);
		if(i< ncmds - 1){
		  close(parent_pipe[1]);
		}
		
                execute(cmds[i]);
                exit(1);
            }
            pids[i] = cpid;
        }

        for (i = 0; i < ncmds - 1; i++) { 
	  close(pipes[i][0]);
	  close(pipes[i][1]); 
	}
        close(parent_pipe[1]);

	for (i = 0; i < ncmds; i++) { 
	  int st; waitpid(pids[i], &st, 0); 
	}

        total = 0;
        outbuf = NULL;
        while ((rn = read(parent_pipe[0], buf, sizeof(buf))) > 0) {
            write(STDOUT_FILENO, buf, rn);
            {
                char *tmp = realloc(outbuf, total + (size_t)rn + 1);
                if (!tmp) { free(outbuf); outbuf = NULL; break; }
                outbuf = tmp;
                memcpy(outbuf + total, buf, (size_t)rn);
                total += (size_t)rn;
                outbuf[total] = '\0';
            }
        }

        if (outbuf) { 
	  t->output = outbuf; ret_val = 0; 
	} else {
	  t->output = NULL; 
	}
        close(parent_pipe[0]);

        

        return ret_val;
    }else if(t->conjunction == SUBSHELL){
      pid_t pid;
      int status;

      pid = fork();
      if(pid == 0){
	int r = 0;
	if(t->left != NULL)
	  r = execute(t->left);
	exit(r==0 ? 0:1);
      }
      waitpid(pid, &status,0);

      if(WIFEXITED(status) && WEXITSTATUS(status) == 0)
	ret_val == 0;
      else
	ret_val = -1;
    }

    return ret_val;
}

static void print_tree(struct tree *t) {
    if (t != NULL) {
        print_tree(t->left);
        if (t->conjunction == NONE) printf("NONE: %s, ", t->argv[0]);
        else printf("%s, ", conj[t->conjunction]);
        printf("IR: %s, ", t->input ? t->input : "NULL");
        printf("OR: %s\n", t->output ? t->output : "NULL");
        print_tree(t->right);
    }
}
